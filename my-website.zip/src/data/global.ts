import { SectionType } from "../types/global";

export const data: SectionType[] = [
  {
    imgUrl: "https://source.unsplash.com/random/?porsche",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid exercitationem sunt consequatur sint voluptatem vitae. Eos quaerat ipsa quisquam consequatur impedit maiores omnis possimus quia, facilis sed alias vero delectus.",
  },
  {
    imgUrl: "https://source.unsplash.com/random/?ferrari",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid exercitationem sunt consequatur sint voluptatem vitae. Eos quaerat ipsa quisquam consequatur impedit maiores omnis possimus quia, facilis sed alias vero delectus.",
  },
  {
    imgUrl: "https://source.unsplash.com/random/?lamborghini",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid exercitationem sunt consequatur sint voluptatem vitae. Eos quaerat ipsa quisquam consequatur impedit maiores omnis possimus quia, facilis sed alias vero delectus.",
  },
  {
    imgUrl: "https://source.unsplash.com/random/?audi",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid exercitationem sunt consequatur sint voluptatem vitae. Eos quaerat ipsa quisquam consequatur impedit maiores omnis possimus quia, facilis sed alias vero delectus.",
  },
];
